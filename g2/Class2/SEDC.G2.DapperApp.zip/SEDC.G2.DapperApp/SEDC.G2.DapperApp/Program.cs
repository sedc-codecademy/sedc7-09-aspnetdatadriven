﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEDC.G2.DapperApp
{
    class Program
    {
        //data source=palmyra##; initial catalog=PizzaAppDB;persisted Security info=True;user id=sa;password=Password1
        private static string _connectionString = @"Server=DESKTOP-CO6AHNV\SQLEXPRESS;Database=Test1DB;Trusted_Connection=True;";
        static void Main(string[] args)
        {
            InsertPizzaExecute();

            Console.ReadLine();
        }

        private static void InsertPizzaExecute()
        {
            var insertQuery = @"Insert into Pizza (Name, Description) values (@Name, @Description)";

            Console.Write("Pizza Name: ");
            var pizzaName = Console.ReadLine();
            Console.Write("Pizza description: ");
            var desc = Console.ReadLine();
            using (var connection = new SqlConnection(_connectionString))
            {
                var affectedRows = connection.Execute(insertQuery, new { Name = pizzaName, Description = desc });
                Console.WriteLine("Response value: " + affectedRows);
            }
        }
    }
}
